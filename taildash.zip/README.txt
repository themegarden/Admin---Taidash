Dashboard is Tailwind CSS Admin Dashboard Template that comes with all essential - dashboard components, elements and pages that are required to build a full-featured and data-rich back-end, dashboard, admin panel solution for your next web projects. 

This Dashboard template handcrafted for Tailwind CSS to serve multiple purposes for now it provides 2 unique dashboard variations such as - eCommerce and Analytics, we will keep adding new variations based on user feedback.

Included Dashboard Pages and Components:
Dashboards:

Analytics
eCommerce
Apps

Chat
Inbox
Calendar
Profile
Settings
UI Elements

Accordion
Alerts
Badge
Breadcrumb
Buttons
Button Group
Card
Tabs
Pagination
Form Elements

Input
Textarea
File upload
Select Input
Data Tables

Charts and Graph

Auth Pages

Register
Login
Forget password
This template is based on a plain Tailwind CSS coded in HTML + Tailwind CSS for interactions we have used in Alpine JS.

If you are looking for a great looking solid Tailwind CSS dashboard or admin template, Dashboard will be the perfect choice for you!



Update Logs- 1.1
Fixed Mobile Navbar Issue on Safari